package com.pullenti.unisharp;

public interface Action<T> {

    void call(T obj);
}
