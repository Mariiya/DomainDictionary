package com.pullenti.unisharp;

public class Outargwrapper<T> {
    public Outargwrapper() { }
    public Outargwrapper(T a) { value = a; }
    public T value; 
}
