package com.pullenti.unisharp;

public class CancelEventArgs {
    public CancelEventArgs(boolean c) { cancel = c; }
    public CancelEventArgs() { }
    public boolean cancel;
}
