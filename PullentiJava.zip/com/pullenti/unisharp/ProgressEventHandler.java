package com.pullenti.unisharp;

public interface ProgressEventHandler {

    void call(Object sender, ProgressEventArgs arg);
}
