package com.pullenti.unisharp;

public interface CancelEventHandler {

    void call(Object sender, CancelEventArgs arg);
}
