package com.pullenti.unisharp;

public class RegexGroupWrapper {

	public int index;
	public int length;
	public String value;
	@Override
	public String toString() {
		return value;
	}
}
